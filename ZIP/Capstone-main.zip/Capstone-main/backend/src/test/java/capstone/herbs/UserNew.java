package capstone.herbs;

record UserNew(String name) {
}