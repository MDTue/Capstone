# Hoerbs Webanwendung

Die Anwendung ergänzt den Instagram Account 'hoerbs'.
Daher kommt auch die ungewöhnliche Schreibweise: Da alle möglichen Schreibweisen bereits vergeben waren, 
wurde als Accountname die lautmalerische Schreibweise von 'herbs' übernommen.

Die Anwendung bietet die Online-PLattform für ein offenes Herbarium. 
Auf der linken Seite werden alle bereits erfassten Pflanzen aufgeführt.
Mit Klick auf eine Pflanze werden deren Eigenschaften im mittleren Block angezeigt.

Je nach Rechten haben angemeldete User unterschiedliche Befugnisse:
User mit der Rolle 'User' können eine neue Pflanze eingeben. Dieser Datensatz braucht aber die Freigabe eines Admin-Users, um in den Pool aufgenommen zu werden.
Admin-User können demzufolge die Freigabe für einen Datensatz erteilen und Datensätze löschen.



