
import HerbsPage from "./Herbs/HerbsPage";

function App() {

    return (
        <HerbsPage/>
    );
}

export default App;
