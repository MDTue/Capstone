
import {HerbsItemDTO} from "../Herbs/HerbsModel";

interface HerbsItemProps{
    herbsItem : HerbsItemDTO
}

export default function HerbsItem(props:HerbsItemProps){

}


